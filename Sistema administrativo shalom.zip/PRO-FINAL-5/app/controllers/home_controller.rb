class HomeController < ApplicationController
  before_action :set_product, only: [:edit, :update, :destroy, :show]
  before_action :set_categories, only: [:new, :edit, :create]
  before_action :set_suppliers, only: [:new, :edit, :create]
  before_action :set_clients, only: [:new, :edit, :create]
  before_action :set_sales, only: [:new, :edit, :create]
  before_action :set_warehouses, only: [:new, :edit, :create]

  def index
    @productos = Product.all
    @categorias = Category.all
    @proveedores = Supplier.all
    @clientes = Client.all
    @ventas = Sale.all
    @entradas_almacen = WarehouseRecord.all
    @nombre = current_user.profile.nombre.blank? ? current_user.email : current_user.profile.nombre

    respond_to do |format|
      format.xlsx{
        response.headers[
          'Content-Disposition'
        ] = "attachment; filename= REPORTE-GENERAL.xlsx"
      }
      format.html { render :index}
    end
  end

   private
  def product_params
    params.require(:product).permit(:imagen, :nombre, :descripcion, :existencia, :precio, :category_id, :supplier_id)
  end

  def set_product
    @product = Product.find(params[:id])
  end

  def set_categories
    @categorias = Category.all
  end

  def set_suppliers
    @proveedores = Supplier.all
  end
  def set_clients
    @clientes = Client.all
  end
  def set_sales
    @ventas = Sale.all
  end
  def set_warehouses
    @entradas_almacen = WarehouseRecord.all
  end


end
